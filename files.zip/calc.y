/*
 * calc.y —— Bison 语法文件
 *
 * 关键指令：
 *
 *   %parse-param { ParseState *ps }
 *     → yyparse 原型变为: int yyparse(ParseState *ps)
 *     → MySQL 对应:       int MYSQLparse(THD *thd)
 *
 *   %lex-param   { ParseState *ps }
 *     → yyparse 内部调用 yylex 时额外传入 ps
 *     → yylex 原型变为:  int yylex(YYSTYPE *yylval, ParseState *ps)
 *     → MySQL 对应:      int MYSQLlex(YYSTYPE *yylval, THD *thd)
 *
 * 这样整个解析过程无任何全局变量，ps 作为上下文贯穿始终。
 */

%{
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "parser_state.h"

/* 改变原型后的 yylex 声明 */
int yylex(YYSTYPE *yylval, ParseState *ps);

/* 改变原型后的 yyerror 声明 */
void yyerror(ParseState *ps, const char *msg);
%}

/* ─────────────────────────────────────────
 * 改变 yyparse / yylex 原型的核心指令
 * ───────────────────────────────────────── */
%parse-param { ParseState *ps }   /* yyparse(ParseState *ps)        */
%lex-param   { ParseState *ps }   /* yylex(YYSTYPE*, ParseState *ps) */

/* ── 语义值联合体 ── */
%union {
    double dval;
}

/* ── Token 声明 ── */
%token <dval> TOKEN_NUM

/* ── 非终结符类型 ── */
%type <dval> expr term power unary primary

/* ── 优先级与结合性（低 → 高） ── */
%left  '+' '-'
%left  '*' '/' '%'
%right '^'
%right UMINUS

%define parse.error verbose   /* 让 yyerror 收到详细错误信息 */

%%

/* ════════════════════════════════════════
 *  input: 支持单行表达式
 * ════════════════════════════════════════ */
input
    : expr '\n'     { ps->result = $1; }
    | '\n'          { ps->result = 0;  }
    | error '\n'    { yyerrok; }
    ;

/* ════════════════════════════════════════
 *  expr → term { (+|-) term }   左结合
 * ════════════════════════════════════════ */
expr
    : expr '+' term  { $$ = $1 + $3; }
    | expr '-' term  { $$ = $1 - $3; }
    | term           { $$ = $1; }
    ;

/* ════════════════════════════════════════
 *  term → power { (*|/|%) power }  左结合
 * ════════════════════════════════════════ */
term
    : term '*' power  { $$ = $1 * $3; }
    | term '/' power  {
          if ($3 == 0) { yyerror(ps, "除以零"); $$ = 0; }
          else          $$ = $1 / $3;
      }
    | term '%' power  {
          if ($3 == 0) { yyerror(ps, "模除以零"); $$ = 0; }
          else          $$ = fmod($1, $3);
      }
    | power           { $$ = $1; }
    ;

/* ════════════════════════════════════════
 *  power → unary [^ power]   右结合
 * ════════════════════════════════════════ */
power
    : unary '^' power  { $$ = pow($1, $3); }
    | unary            { $$ = $1; }
    ;

/* ════════════════════════════════════════
 *  unary → (-|+) unary | primary
 * ════════════════════════════════════════ */
unary
    : '-' unary %prec UMINUS  { $$ = -$2; }
    | '+' unary %prec UMINUS  { $$ =  $2; }
    | primary                 { $$ = $1;  }
    ;

/* ════════════════════════════════════════
 *  primary → NUMBER | ( expr )
 * ════════════════════════════════════════ */
primary
    : TOKEN_NUM       { $$ = $1; }
    | '(' expr ')'    { $$ = $2; }
    ;

%%

/* ── yyerror：接收 ps 参数，将错误写入上下文 ── */
void yyerror(ParseState *ps, const char *msg) {
    ps->has_error = 1;
    snprintf(ps->errmsg, sizeof(ps->errmsg), "%s", msg);
}
