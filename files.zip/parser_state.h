#ifndef PARSER_STATE_H
#define PARSER_STATE_H

/*
 * ParseState —— 贯穿整个解析过程的上下文
 *
 * MySQL 的做法：THD (Thread Handle) 作为参数穿透 yylex/yyparse，
 * 这里我们用 ParseState 模拟同样的思路：
 *   - 词法状态（输入缓冲区、当前位置）
 *   - 语义结果（最终计算值）
 *   - 错误信息
 *
 * 好处：无全局变量，天然线程安全，可同时运行多个解析实例。
 */
typedef struct {
    /* ── 词法状态（供手写 yylex 使用） ── */
    const char *buf;        /* 当前输入行               */
    int         pos;        /* 扫描位置                 */

    /* ── 语义结果 ── */
    double      result;     /* 表达式计算结果           */

    /* ── 错误状态 ── */
    int         has_error;
    char        errmsg[128];
} ParseState;

#endif /* PARSER_STATE_H */
