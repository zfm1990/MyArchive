/*
 * main.c —— REPL 主循环
 *
 * 核心调用方式（对比 MySQL）：
 *
 *   标准 Bison:    yyparse()
 *   本项目:        yyparse(&ps)          // ps 作为参数传入
 *   MySQL:         MYSQLparse(thd)       // thd 作为参数传入
 *
 * ps 中包含词法状态、计算结果、错误信息，
 * 整个解析过程零全局变量。
 */

#include <stdio.h>
#include <string.h>
#include "parser_state.h"
#include "calc.tab.h"

/* Bison 生成，但原型已被 %parse-param 改变 */
extern int yyparse(ParseState *ps);

#define MAX_LINE 1024

static void print_banner(void) {
    printf("\033[1;36m");
    printf("┌──────────────────────────────────────────┐\n");
    printf("│  Calculator  （自定义 yylex/yyparse 原型）│\n");
    printf("└──────────────────────────────────────────┘\n");
    printf("\033[0m");
    printf("运算符: + - * / %% ^ ( )       quit 退出\n\n");
}

int main(void) {
    char line[MAX_LINE];

    print_banner();

    while (1) {
        printf("\033[1;33m» \033[0m");
        fflush(stdout);

        if (!fgets(line, sizeof(line), stdin))
            break;

        /* 退出命令 */
        if (strncmp(line, "quit", 4) == 0 ||
            strncmp(line, "exit", 4) == 0) {
            printf("再见！\n");
            break;
        }

        /*
         * 初始化 ParseState：
         *   - buf/pos  供 yylex 的 YY_INPUT 宏读取字符
         *   - result   yyparse 执行后写入计算结果
         */
        ParseState ps = {
            .buf       = line,
            .pos       = 0,
            .result    = 0.0,
            .has_error = 0,
            .errmsg    = ""
        };

        /*
         * 调用改变原型后的 yyparse：
         *   int yyparse(ParseState *ps)
         *
         * yyparse 内部每次需要 Token 时调用：
         *   int yylex(YYSTYPE *yylval, ParseState *ps)
         *
         * ps 如同 MySQL 的 THD，贯穿整个解析过程。
         */
        yyparse(&ps);

        if (ps.has_error) {
            printf("\033[31m  错误: %s\033[0m\n\n", ps.errmsg);
        } else {
            printf("  \033[1;32m= %g\033[0m\n\n", ps.result);
        }
    }

    return 0;
}
